"""
Generate the 1-page concept report PDF for Assignment 2.
"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

OUT = "/home/claude/disasters/concept_report.pdf"

doc = SimpleDocTemplate(
    OUT, pagesize=A4,
    leftMargin=2*cm, rightMargin=2*cm,
    topMargin=1.7*cm, bottomMargin=1.7*cm,
    title="Concept Report — Natural Disasters Risk Dashboard",
    author="Krenar",
)

styles = getSampleStyleSheet()
title = ParagraphStyle(
    "TitleX", parent=styles["Title"], fontSize=14, leading=17,
    spaceAfter=4, alignment=TA_LEFT, fontName="Helvetica-Bold",
)
sub = ParagraphStyle(
    "Sub", parent=styles["Normal"], fontSize=8.5, leading=11,
    textColor="#555555", spaceAfter=10,
)
h2 = ParagraphStyle(
    "H2", parent=styles["Heading2"], fontSize=10.5, leading=13,
    spaceBefore=6, spaceAfter=2, fontName="Helvetica-Bold",
)
body = ParagraphStyle(
    "Body", parent=styles["Normal"], fontSize=9.5, leading=12.5,
    alignment=TA_JUSTIFY, spaceAfter=2,
)
bullet = ParagraphStyle(
    "Bullet", parent=body, leftIndent=12, bulletIndent=0, spaceAfter=1,
)

story = []
story.append(Paragraph("Natural Disasters Risk: A Multi-Source Dashboard", title))
story.append(Paragraph(
    "Interactive Visualization — Assignment 2 (Concept &amp; Dashboard) · "
    "Krenar · JKU Linz",
    sub,
))

story.append(Paragraph("Topic", h2))
story.append(Paragraph(
    "Disaster risk reduction agencies need to anticipate where humanitarian "
    "crises will overwhelm national response capacity. The INFORM Risk Index "
    "operationalises this with a composite score combining hazard exposure, "
    "population vulnerability, and lack of coping capacity. This dashboard "
    "lets a user explore the global INFORM risk landscape and, crucially, "
    "compare predicted risk against the disaster losses actually observed in "
    "EM-DAT over the last three decades — surfacing both well-modelled "
    "countries and outliers that the index over- or under-estimates.",
    body,
))

story.append(Paragraph("Dataset", h2))
story.append(Paragraph(
    "<b>INFORM Risk Index</b> (Joint Research Centre, European Commission) — "
    "open-source composite risk assessment covering 191 countries, scored "
    "0–10 across three dimensions (Hazard &amp; Exposure, Vulnerability, "
    "Lack of Coping Capacity) and ~80 underlying indicators. Hazard-specific "
    "sub-scores are available for flood, earthquake, tropical cyclone, drought, "
    "tsunami, and epidemic. Five years of comparable trend data (2022–2026). "
    "Licensed CC-BY-4.0; downloaded as a single Excel workbook from "
    "drmkc.jrc.ec.europa.eu/inform-index.",
    body,
))
story.append(Spacer(1, 2))
story.append(Paragraph(
    "<b>EM-DAT International Disaster Database</b> (CRED, UCLouvain) — "
    "event-level records of 27,000+ disasters from 1900 to present, with "
    "deaths, persons affected, and economic damages per event. We use natural-"
    "hazard events from 1995 onward to give a 30-year window of comparable "
    "modern records. Free for academic use; downloaded as Excel after free "
    "registration at emdat.be.",
    body,
))
story.append(Spacer(1, 2))
story.append(Paragraph(
    "<b>Preprocessing.</b> A Python script (<i>preprocess.py</i>, included) "
    "loads both files, normalises country names to ISO3 codes, filters EM-DAT "
    "to natural hazards, and joins the two on country code. Outputs are four "
    "tidy CSVs imported into Power BI: <i>inform_latest</i>, <i>inform_trend</i>, "
    "<i>emdat_events</i>, and <i>joined_summary</i>.",
    body,
))

story.append(Paragraph("User Tasks", h2))
for t in [
    "<b>T1 — Identify:</b> which countries face the highest composite risk, "
        "and which hazard types dominate their profile.",
    "<b>T2 — Decompose:</b> for a selected country, break down the INFORM "
        "score into its three dimensions and read the indicator-level drivers.",
    "<b>T3 — Compare:</b> place a country against its regional peers and "
        "against its own five-year trajectory.",
    "<b>T4 — Reconcile:</b> contrast predicted INFORM risk with observed "
        "EM-DAT losses (deaths, affected, damages) to surface under- and "
        "over-predicted countries.",
]:
    story.append(Paragraph(f"• {t}", bullet))

story.append(Paragraph("Dashboard (Power BI, 4 pages)", h2))
for t in [
    "<b>Global Overview</b> — choropleth of INFORM Risk; top/bottom-10 "
        "ranking; hazard-type filter; year slider. Drives cross-page filtering.",
    "<b>Country Profile</b> — selected country's three-dimension breakdown, "
        "hazard-specific scores, 5-year trend line, and regional benchmark.",
    "<b>Event History</b> — EM-DAT timeline (stacked area by hazard type), "
        "with parallel views for deaths, persons affected, and damages.",
    "<b>Risk vs. Reality</b> — scatter of INFORM score against 30-year loss "
        "metric, log y-axis, region colour-coded; the diagonal residual flags "
        "outliers and motivates Assignment 3.",
]:
    story.append(Paragraph(f"• {t}", bullet))

story.append(Paragraph("Outlook (Assignment 3)", h2))
story.append(Paragraph(
    "The reconciliation view (page 4) is the obvious anchor for a custom D3 "
    "component: a radial &ldquo;risk fingerprint&rdquo; per country — petals encoding "
    "the hazard-specific scores, brightness encoding realised losses — with a "
    "linked event scatter. This pushes beyond Power BI's stock charts on both "
    "the visual encoding (custom radial geometry, dual encoding) and the "
    "interaction (brushing across linked views).",
    body,
))

doc.build(story)
print(f"Wrote {OUT}")
