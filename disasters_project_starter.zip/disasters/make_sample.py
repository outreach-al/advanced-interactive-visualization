"""
Generate a small realistic synthetic INFORM-style sample so we can prototype
the dashboard while waiting for Krenar to download the real data.

The structure mirrors what the real INFORM_Risk_*.xlsx will contain:
- ISO3 country code, country name, region, income group
- INFORM Risk score (0-10)
- Three dimensions: Hazard & Exposure, Vulnerability, Lack of Coping Capacity
- A few hazard-specific risk scores: Flood, Earthquake, Tropical Cyclone, Drought
- 5-year trend (2022-2026)

Plus EM-DAT-style event aggregates per country (1995-2025):
- total_disasters, total_deaths, total_affected, total_damages_musd
"""
import csv, json, random, math

random.seed(42)

# Hand-picked country list spanning regions & risk levels so the dashboard
# demos well. Real INFORM has 191 countries; this sample has 30.
COUNTRIES = [
    # ISO3, name, region, income, baseline_risk (rough INFORM 2024 numbers, lightly fuzzed)
    ("SOM", "Somalia",        "Africa",       "Low",          8.8),
    ("SSD", "South Sudan",    "Africa",       "Low",          8.6),
    ("COD", "DR Congo",       "Africa",       "Low",          8.0),
    ("AFG", "Afghanistan",    "Asia",         "Low",          8.5),
    ("YEM", "Yemen",          "Asia",         "Low",          8.3),
    ("SYR", "Syria",          "Asia",         "Low",          7.9),
    ("HTI", "Haiti",          "Americas",     "Low",          7.6),
    ("ETH", "Ethiopia",       "Africa",       "Low",          7.3),
    ("MMR", "Myanmar",        "Asia",         "Lower-Middle", 7.1),
    ("PAK", "Pakistan",       "Asia",         "Lower-Middle", 6.8),
    ("BGD", "Bangladesh",     "Asia",         "Lower-Middle", 5.6),
    ("PHL", "Philippines",    "Asia",         "Lower-Middle", 5.7),
    ("IND", "India",          "Asia",         "Lower-Middle", 5.4),
    ("IDN", "Indonesia",      "Asia",         "Upper-Middle", 4.9),
    ("EGY", "Egypt",          "Africa",       "Lower-Middle", 5.0),
    ("MEX", "Mexico",         "Americas",     "Upper-Middle", 4.7),
    ("TUR", "Turkey",         "Asia",         "Upper-Middle", 4.6),
    ("BRA", "Brazil",         "Americas",     "Upper-Middle", 4.0),
    ("CHN", "China",          "Asia",         "Upper-Middle", 4.4),
    ("ZAF", "South Africa",   "Africa",       "Upper-Middle", 4.5),
    ("RUS", "Russia",         "Europe",       "Upper-Middle", 3.9),
    ("CHL", "Chile",          "Americas",     "High",         3.2),
    ("USA", "United States",  "Americas",     "High",         3.4),
    ("ITA", "Italy",          "Europe",       "High",         2.6),
    ("ESP", "Spain",          "Europe",       "High",         2.4),
    ("JPN", "Japan",          "Asia",         "High",         3.0),
    ("DEU", "Germany",        "Europe",       "High",         2.0),
    ("GBR", "United Kingdom", "Europe",       "High",         2.1),
    ("AUT", "Austria",        "Europe",       "High",         1.7),
    ("NOR", "Norway",         "Europe",       "High",         1.4),
]

# Hazard profile multipliers: which hazards each country is most exposed to.
# Used to make hazard-specific scores correlate sensibly with geography.
HAZARD_PROFILES = {
    "SOM": dict(flood=0.9, earthquake=0.2, cyclone=0.6, drought=1.0),
    "SSD": dict(flood=1.0, earthquake=0.2, cyclone=0.1, drought=1.0),
    "COD": dict(flood=0.9, earthquake=0.4, cyclone=0.2, drought=0.7),
    "AFG": dict(flood=0.8, earthquake=1.0, cyclone=0.1, drought=0.9),
    "YEM": dict(flood=0.7, earthquake=0.6, cyclone=0.7, drought=0.9),
    "SYR": dict(flood=0.6, earthquake=0.8, cyclone=0.2, drought=0.8),
    "HTI": dict(flood=0.9, earthquake=1.0, cyclone=1.0, drought=0.5),
    "ETH": dict(flood=0.8, earthquake=0.4, cyclone=0.2, drought=1.0),
    "MMR": dict(flood=1.0, earthquake=0.7, cyclone=0.9, drought=0.5),
    "PAK": dict(flood=1.0, earthquake=0.8, cyclone=0.6, drought=0.7),
    "BGD": dict(flood=1.0, earthquake=0.6, cyclone=1.0, drought=0.5),
    "PHL": dict(flood=0.9, earthquake=0.8, cyclone=1.0, drought=0.4),
    "IND": dict(flood=0.9, earthquake=0.7, cyclone=0.8, drought=0.7),
    "IDN": dict(flood=0.8, earthquake=1.0, cyclone=0.5, drought=0.4),
    "EGY": dict(flood=0.4, earthquake=0.4, cyclone=0.3, drought=0.9),
    "MEX": dict(flood=0.7, earthquake=0.9, cyclone=0.9, drought=0.6),
    "TUR": dict(flood=0.6, earthquake=1.0, cyclone=0.2, drought=0.6),
    "BRA": dict(flood=0.7, earthquake=0.2, cyclone=0.2, drought=0.7),
    "CHN": dict(flood=0.9, earthquake=0.9, cyclone=0.8, drought=0.7),
    "ZAF": dict(flood=0.5, earthquake=0.3, cyclone=0.4, drought=0.8),
    "RUS": dict(flood=0.5, earthquake=0.4, cyclone=0.2, drought=0.4),
    "CHL": dict(flood=0.6, earthquake=1.0, cyclone=0.2, drought=0.6),
    "USA": dict(flood=0.7, earthquake=0.7, cyclone=0.8, drought=0.6),
    "ITA": dict(flood=0.6, earthquake=0.7, cyclone=0.2, drought=0.5),
    "ESP": dict(flood=0.5, earthquake=0.4, cyclone=0.2, drought=0.6),
    "JPN": dict(flood=0.7, earthquake=1.0, cyclone=0.9, drought=0.2),
    "DEU": dict(flood=0.5, earthquake=0.2, cyclone=0.1, drought=0.3),
    "GBR": dict(flood=0.6, earthquake=0.1, cyclone=0.2, drought=0.2),
    "AUT": dict(flood=0.5, earthquake=0.2, cyclone=0.1, drought=0.2),
    "NOR": dict(flood=0.4, earthquake=0.1, cyclone=0.1, drought=0.1),
}


def jitter(value, sd):
    """Gaussian jitter clipped to [0, 10]."""
    return max(0.0, min(10.0, random.gauss(value, sd)))


# ---- 1. Country-level INFORM-style table (long format, one row per country-year) ----
rows = []
for iso3, name, region, income, base_risk in COUNTRIES:
    # Build dimension scores that are correlated with overall risk but distinct
    hazard_dim     = jitter(base_risk * 0.95, 0.4)
    vulnerability  = jitter(base_risk * 1.02 + random.uniform(-0.8, 0.8), 0.4)
    coping         = jitter(base_risk * 0.98 + random.uniform(-0.5, 0.5), 0.4)
    # Overall ≈ geometric-ish mean of the three (loosely follows INFORM's formula)
    overall = (hazard_dim * vulnerability * coping) ** (1/3)

    # 5-year trend: small drift around the baseline
    drift = random.uniform(-0.15, 0.15)  # per-year drift
    for year_offset, year in enumerate([2022, 2023, 2024, 2025, 2026]):
        year_overall = max(0.0, min(10.0, overall + drift * (year_offset - 2) + random.gauss(0, 0.08)))
        year_hazard  = max(0.0, min(10.0, hazard_dim + drift * (year_offset - 2) + random.gauss(0, 0.1)))
        year_vuln    = max(0.0, min(10.0, vulnerability + drift * (year_offset - 2) + random.gauss(0, 0.1)))
        year_cope    = max(0.0, min(10.0, coping + drift * (year_offset - 2) + random.gauss(0, 0.1)))

        prof = HAZARD_PROFILES[iso3]
        # Hazard-specific risk: profile × baseline, with jitter
        flood   = jitter(year_hazard * prof["flood"], 0.3)
        eq      = jitter(year_hazard * prof["earthquake"], 0.3)
        cyclone = jitter(year_hazard * prof["cyclone"], 0.3)
        drought = jitter(year_hazard * prof["drought"], 0.3)

        rows.append({
            "iso3": iso3, "country": name, "region": region, "income_group": income,
            "year": year,
            "inform_risk": round(year_overall, 2),
            "hazard_exposure": round(year_hazard, 2),
            "vulnerability": round(year_vuln, 2),
            "lack_of_coping_capacity": round(year_cope, 2),
            "risk_flood": round(flood, 2),
            "risk_earthquake": round(eq, 2),
            "risk_tropical_cyclone": round(cyclone, 2),
            "risk_drought": round(drought, 2),
        })

with open("inform_sample.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
print(f"Wrote inform_sample.csv: {len(rows)} rows")


# ---- 2. EM-DAT-style event sample (one row per event) ----
# Loosely calibrated to real-world frequencies: high-risk countries get more
# events with larger impacts.
HAZARD_TYPES = ["Flood", "Earthquake", "Storm", "Drought", "Wildfire", "Extreme temperature"]
events = []
event_id = 1
for iso3, name, region, income, base_risk in COUNTRIES:
    # Roughly: high-risk countries see ~50 events in 30yr, low-risk see ~10
    n_events = max(3, int(random.gauss(base_risk * 6, 5)))
    prof = HAZARD_PROFILES[iso3]
    for _ in range(n_events):
        year = random.randint(1995, 2025)
        # Pick a hazard weighted by the country's profile
        weights = [prof["flood"], prof["earthquake"], prof["cyclone"], prof["drought"], 0.3, 0.3]
        htype = random.choices(HAZARD_TYPES, weights=weights, k=1)[0]
        # Impact scales with baseline risk; lognormal-ish
        deaths   = int(max(0, random.lognormvariate(math.log(max(1, base_risk * 5)), 1.5)))
        affected = int(max(0, random.lognormvariate(math.log(max(100, base_risk * 5000)), 1.6)))
        damages  = round(max(0, random.lognormvariate(math.log(max(1, base_risk * 20)), 1.4)), 1)  # M USD
        events.append({
            "event_id": f"E{event_id:05d}",
            "iso3": iso3, "country": name, "region": region,
            "year": year,
            "hazard_type": htype,
            "deaths": deaths,
            "affected": affected,
            "damages_musd": damages,
        })
        event_id += 1

with open("emdat_sample.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(events[0].keys()))
    w.writeheader()
    w.writerows(events)
print(f"Wrote emdat_sample.csv: {len(events)} rows")


# ---- 3. Country-level joined summary (latest INFORM year + 30-yr EM-DAT totals) ----
# This is what Page 4 of the dashboard (Risk vs Reality scatter) will use.
latest_inform = {r["iso3"]: r for r in rows if r["year"] == 2026}
emdat_agg = {}
for e in events:
    a = emdat_agg.setdefault(e["iso3"], {"events": 0, "deaths": 0, "affected": 0, "damages_musd": 0.0})
    a["events"] += 1
    a["deaths"] += e["deaths"]
    a["affected"] += e["affected"]
    a["damages_musd"] += e["damages_musd"]

joined = []
for iso3, ir in latest_inform.items():
    em = emdat_agg.get(iso3, {"events": 0, "deaths": 0, "affected": 0, "damages_musd": 0.0})
    joined.append({
        "iso3": iso3, "country": ir["country"], "region": ir["region"],
        "income_group": ir["income_group"],
        "inform_risk_2026": ir["inform_risk"],
        "hazard_exposure": ir["hazard_exposure"],
        "vulnerability": ir["vulnerability"],
        "lack_of_coping_capacity": ir["lack_of_coping_capacity"],
        "total_events_1995_2025": em["events"],
        "total_deaths_1995_2025": em["deaths"],
        "total_affected_1995_2025": em["affected"],
        "total_damages_musd_1995_2025": round(em["damages_musd"], 1),
    })

with open("joined_summary.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(joined[0].keys()))
    w.writeheader()
    w.writerows(joined)
print(f"Wrote joined_summary.csv: {len(joined)} rows")

# Also emit a compact JSON for the D3 prototype
with open("joined_summary.json", "w") as f:
    json.dump(joined, f, indent=2)
print("Wrote joined_summary.json")
