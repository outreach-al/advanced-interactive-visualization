"""
preprocess.py — Build Power BI–ready CSVs from raw INFORM + EM-DAT downloads.

USAGE
-----
Put your downloaded files in ./raw/ :
  raw/INFORM_Risk_2026.xlsx           (from drmkc.jrc.ec.europa.eu/inform-index)
  raw/INFORM_TREND_2015_2026.xlsx     (optional, for the 5-year trend page)
  raw/emdat_public.xlsx               (from emdat.be — register and download)

Run:
  python preprocess.py

Outputs (./out/):
  inform_latest.csv          One row per country, latest INFORM year
  inform_trend.csv           One row per country-year (long format)
  emdat_events.csv           Cleaned event-level table
  joined_summary.csv         INFORM (latest) + EM-DAT (30yr aggregates) joined on ISO3
  README.txt                 Notes for Power BI import

NOTE ON COLUMN NAMES
--------------------
INFORM's Excel layout has shifted across years (sometimes "INFORM Risk" is a
column, sometimes the score sits under a multi-row header). The script tries
the most common patterns; if it fails, read the first warning and fix the
COL_MAP at the top.
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np
import re
import sys

RAW = Path("raw")
OUT = Path("out")
OUT.mkdir(exist_ok=True)


# ---- Configurable column mapping --------------------------------------------
# Keys are normalized lowercase target names; values are lists of candidate
# header strings (case-insensitive substring match) to look for in the Excel.
COL_MAP = {
    "iso3":                    ["iso3", "country code", "iso 3"],
    "country":                 ["country name", "country"],
    "inform_risk":             ["inform risk", "risk index", "inform"],
    "hazard_exposure":         ["hazard & exposure", "hazard and exposure", "hazard exposure"],
    "vulnerability":           ["vulnerability"],
    "lack_of_coping_capacity": ["lack of coping", "coping capacity"],
    "risk_flood":              ["flood risk", "flood"],
    "risk_earthquake":         ["earthquake"],
    "risk_tropical_cyclone":   ["tropical cyclone", "cyclone"],
    "risk_drought":            ["drought"],
}


def normalize(s: str) -> str:
    return re.sub(r"\s+", " ", str(s)).strip().lower()


def find_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    """Return the first column whose normalized name contains any candidate."""
    norm_cols = {c: normalize(c) for c in df.columns}
    for c, n in norm_cols.items():
        for cand in candidates:
            if cand in n:
                return c
    return None


def find_inform_sheet(xlsx_path: Path) -> tuple[str, pd.DataFrame]:
    """Find the sheet that looks like the main INFORM results table."""
    xl = pd.ExcelFile(xlsx_path)
    # INFORM Excels typically have a sheet called "INFORM Risk" or "Results"
    # with the indicator table. We pick the sheet whose header row mentions
    # both 'ISO3' and 'Risk'.
    best = None
    for sn in xl.sheet_names:
        # Try with several header rows since INFORM uses multi-row headers
        for header_row in range(5):
            try:
                df = pd.read_excel(xlsx_path, sheet_name=sn, header=header_row, nrows=3)
                cols = " ".join(str(c).lower() for c in df.columns)
                if "iso3" in cols and ("risk" in cols or "inform" in cols):
                    # Reload with that header row, full data
                    full = pd.read_excel(xlsx_path, sheet_name=sn, header=header_row)
                    print(f"  → Using sheet '{sn}' with header row {header_row}")
                    return sn, full
            except Exception:
                continue
    raise RuntimeError(f"Could not find INFORM data sheet in {xlsx_path}")


def load_inform_latest() -> pd.DataFrame:
    inform_path = next(iter(RAW.glob("INFORM_Risk_*.xlsx")), None) \
                  or next(iter(RAW.glob("inform*.xlsx")), None)
    if not inform_path:
        print("WARN: no INFORM Risk Excel found in raw/. Skipping.")
        return pd.DataFrame()
    print(f"Loading INFORM from {inform_path}")
    _, df = find_inform_sheet(inform_path)

    # Build the output table by mapping columns
    out = {}
    missing = []
    for target, cands in COL_MAP.items():
        src = find_col(df, cands)
        if src is None:
            missing.append(target)
            continue
        out[target] = df[src]
    if missing:
        print(f"  ! Could not map: {missing}. Edit COL_MAP at top of script.")
    result = pd.DataFrame(out).dropna(subset=["iso3"])
    # Cast scores to float
    for c in result.columns:
        if c not in ("iso3", "country"):
            result[c] = pd.to_numeric(result[c], errors="coerce")
    # Drop summary/group rows
    result = result[result["iso3"].astype(str).str.len() == 3]
    print(f"  → {len(result)} country rows")
    return result


def load_inform_trend() -> pd.DataFrame:
    p = next(iter(RAW.glob("INFORM_TREND*.xlsx")), None) \
        or next(iter(RAW.glob("*TREND*.xlsx")), None)
    if not p:
        print("INFO: no INFORM TREND file found; skipping trend output.")
        return pd.DataFrame()
    print(f"Loading INFORM TREND from {p}")
    # TREND files have one sheet per indicator; we want overall INFORM Risk.
    xl = pd.ExcelFile(p)
    # The overall risk sheet is usually named "INFORM Risk" or similar
    target_sheet = None
    for sn in xl.sheet_names:
        if normalize(sn) in ("inform risk", "inform_risk", "overall", "results"):
            target_sheet = sn
            break
    if target_sheet is None:
        # Fallback: first sheet
        target_sheet = xl.sheet_names[0]
        print(f"  ! No obvious 'INFORM Risk' sheet; using first sheet '{target_sheet}'")
    df = pd.read_excel(p, sheet_name=target_sheet)
    # Trend sheets are usually wide: iso3, country, ..., 2015, 2016, ..., 2026
    iso_col = find_col(df, ["iso3"])
    name_col = find_col(df, ["country"])
    year_cols = [c for c in df.columns if re.fullmatch(r"\d{4}", str(c).strip())]
    if not year_cols:
        print("  ! No year columns found. Skipping trend output.")
        return pd.DataFrame()
    long = df.melt(id_vars=[iso_col, name_col], value_vars=year_cols,
                   var_name="year", value_name="inform_risk")
    long = long.rename(columns={iso_col: "iso3", name_col: "country"})
    long["year"] = long["year"].astype(int)
    long["inform_risk"] = pd.to_numeric(long["inform_risk"], errors="coerce")
    long = long.dropna(subset=["inform_risk"])
    long = long[long["iso3"].astype(str).str.len() == 3]
    print(f"  → {len(long)} country-year rows")
    return long


def load_emdat() -> pd.DataFrame:
    p = next(iter(RAW.glob("emdat*.xlsx")), None) \
        or next(iter(RAW.glob("*EM-DAT*.xlsx")), None) \
        or next(iter(RAW.glob("public_emdat*.xlsx")), None)
    if not p:
        print("WARN: no EM-DAT Excel found in raw/. Skipping.")
        return pd.DataFrame()
    print(f"Loading EM-DAT from {p}")
    # EM-DAT public export has a single data sheet; header is on row 1
    df = pd.read_excel(p, sheet_name=0)
    # Keep natural-hazard rows only (EM-DAT also has 'Technological')
    if "Disaster Group" in df.columns:
        df = df[df["Disaster Group"].astype(str).str.lower() == "natural"]
    elif "Disaster Subgroup" in df.columns:
        # In older exports, group column may be missing — keep all
        pass

    keep_map = {
        "ISO":            "iso3",
        "Country":        "country",
        "Region":         "region",
        "Start Year":     "year",
        "Disaster Type":  "hazard_type",
        "Total Deaths":   "deaths",
        "Total Affected": "affected",
        "Total Damage (\'000 US$)": "damages_kusd",
    }
    cols_present = {k: v for k, v in keep_map.items() if k in df.columns}
    df = df[list(cols_present.keys())].rename(columns=cols_present)
    df["year"] = pd.to_numeric(df["year"], errors="coerce")
    for c in ("deaths", "affected", "damages_kusd"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)
    if "damages_kusd" in df.columns:
        df["damages_musd"] = df["damages_kusd"] / 1000.0
        df = df.drop(columns=["damages_kusd"])
    df = df.dropna(subset=["iso3", "year"])
    df["year"] = df["year"].astype(int)
    print(f"  → {len(df)} disaster events")
    return df


def main():
    if not RAW.exists():
        print(f"ERROR: create a './raw/' directory and put downloaded files in it.")
        sys.exit(1)

    inform = load_inform_latest()
    trend  = load_inform_trend()
    emdat  = load_emdat()

    if not inform.empty:
        inform.to_csv(OUT / "inform_latest.csv", index=False)
        print(f"✓ Wrote out/inform_latest.csv")
    if not trend.empty:
        trend.to_csv(OUT / "inform_trend.csv", index=False)
        print(f"✓ Wrote out/inform_trend.csv")
    if not emdat.empty:
        emdat.to_csv(OUT / "emdat_events.csv", index=False)
        print(f"✓ Wrote out/emdat_events.csv")

    # ---- Joined summary ----
    if not inform.empty and not emdat.empty:
        recent = emdat[emdat["year"] >= 1995]
        agg = recent.groupby("iso3").agg(
            total_events=("year", "count"),
            total_deaths=("deaths", "sum"),
            total_affected=("affected", "sum"),
            total_damages_musd=("damages_musd", "sum") if "damages_musd" in recent.columns else ("year", "count"),
        ).reset_index()
        joined = inform.merge(agg, on="iso3", how="left").fillna(
            {"total_events": 0, "total_deaths": 0, "total_affected": 0, "total_damages_musd": 0}
        )
        joined.to_csv(OUT / "joined_summary.csv", index=False)
        print(f"✓ Wrote out/joined_summary.csv ({len(joined)} rows)")

    # ---- README for Power BI import ----
    (OUT / "README.txt").write_text("""\
Power BI import order:

1. Get Data → Text/CSV → inform_latest.csv
   - Mark 'iso3' as data category: Country (in Modeling tab)
2. Get Data → Text/CSV → inform_trend.csv
3. Get Data → Text/CSV → emdat_events.csv
4. Get Data → Text/CSV → joined_summary.csv

Create relationships (Model view):
   inform_latest[iso3]  →  emdat_events[iso3]    (one-to-many)
   inform_latest[iso3]  →  inform_trend[iso3]    (one-to-many)

Recommended measures (DAX):
   Total Deaths       = SUM(emdat_events[deaths])
   Total Affected     = SUM(emdat_events[affected])
   Total Damages USDm = SUM(emdat_events[damages_musd])
   Event Count        = COUNTROWS(emdat_events)
""")
    print(f"✓ Wrote out/README.txt")


if __name__ == "__main__":
    main()
