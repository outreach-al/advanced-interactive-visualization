# Assignment 2 — Natural Disasters Risk Dashboard

**Course:** Interactive Visualization, JKU Linz
**Student:** Krenar
**Deadline:** 20.05.2026

## What's in this folder

```
disasters/
├── concept_report.pdf          ← 1-page PDF for submission
├── make_report.py              ← script that generated it
├── preprocess.py               ← run after downloading raw data
├── make_sample.py              ← generated the sample CSVs below
├── DOWNLOAD_DATA.md            ← step-by-step data download guide
├── dashboard_spec.md           ← Power BI page-by-page implementation
├── README.md                   ← this file
├── raw/                        ← place downloaded files here (empty for now)
├── out/                        ← preprocess.py writes here
├── samples/inform_sample.csv           ← synthetic preview data (30 countries × 5 yrs)
├── samples/emdat_sample.csv            ← synthetic preview events (~800 rows)
├── samples/joined_summary.csv          ← synthetic joined table (Page 4 preview)
└── samples/joined_summary.json         ← same, as JSON for the D3 prototype
```

## Workflow

1. **Read `DOWNLOAD_DATA.md`** — get the real INFORM and EM-DAT files.
2. **Run `python preprocess.py`** — produces clean CSVs in `out/`.
3. **Open Power BI Desktop** — import the four CSVs, build the four pages per
   `dashboard_spec.md`.
4. **Build the slide deck** — wireframe screenshot from the artifact, plus the
   actual dashboard screenshots once it's built.
5. **Submit ZIP** with: `.pbix`, `concept_report.pdf`, `slides.pptx`, and a
   `data_sources.txt` linking to INFORM and EM-DAT (since EM-DAT can't be
   redistributed).

## What's already done

- ✅ Topic and angle locked: risk vs. realised losses
- ✅ Datasets identified: INFORM Risk Index + EM-DAT
- ✅ 1-page concept report drafted (`concept_report.pdf`)
- ✅ Dashboard structure spec'd (`dashboard_spec.md`)
- ✅ Preprocessing pipeline written (`preprocess.py`)
- ✅ Sample data for prototyping (`*_sample.csv`)
- ✅ Wireframe visual for slides

## What you still need to do

- [ ] Download raw INFORM + EM-DAT
- [ ] Run `preprocess.py`
- [ ] Build the four pages in Power BI
- [ ] Take dashboard screenshots for slides
- [ ] Write slides (~10 slides for a 12-min talk)
- [ ] Practice the demo (Q&A is 5+ min; expect questions on EM-DAT's reporting
      bias and on whether INFORM is forward-looking enough)

## Likely Q&A points

- **"Why these two datasets together?"** INFORM is a-priori risk; EM-DAT is
  ex-post outcome. Pairing them surfaces model error and motivates the
  custom visualisation in Assignment 3.
- **"What about EM-DAT's known under-reporting?"** Acknowledged in
  ScienceDirect's 2025 paper on EM-DAT methodology. We compensate by using
  only post-1995 data, when reporting infrastructure stabilised.
- **"Why log scale on Page 4?"** Disaster losses are heavy-tailed; linear axis
  collapses 95% of the data into a strip near zero.
- **"What's the plan for Assignment 3?"** A custom D3 component: radial
  "risk fingerprint" per country (petals = hazard-specific scores,
  saturation = realised losses), brushable to a linked event scatter.
